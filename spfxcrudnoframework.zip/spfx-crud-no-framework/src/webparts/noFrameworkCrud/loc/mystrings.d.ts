declare interface INoFrameworkCrudWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  ListNameFieldLabel: string;
}

declare module 'NoFrameworkCrudWebPartStrings' {
  const strings: INoFrameworkCrudWebPartStrings;
  export = strings;
}
