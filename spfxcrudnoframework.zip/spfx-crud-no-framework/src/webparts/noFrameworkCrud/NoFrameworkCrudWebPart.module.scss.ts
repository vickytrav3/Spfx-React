/* tslint:disable */
require('./NoFrameworkCrudWebPart.module.css');
const styles = {
  noFrameworkCrud: 'noFrameworkCrud_c34cf888',
  container: 'container_c34cf888',
  row: 'row_c34cf888',
  column: 'column_c34cf888',
  'ms-Grid': 'ms-Grid_c34cf888',
  title: 'title_c34cf888',
  subTitle: 'subTitle_c34cf888',
  description: 'description_c34cf888',
  button: 'button_c34cf888',
  label: 'label_c34cf888',
};

export default styles;
/* tslint:enable */